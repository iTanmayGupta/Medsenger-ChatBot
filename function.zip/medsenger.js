var injury = {skin: {burn: ['burn', 'swelling'], rashes: ['rash', 'itching']}, headache: {migrane: ['pain', 'regularly']}};
var dis_type;
var skin = ["sikn","iskn","skinn","sskin",'sjin'];
console.log("Welcome to Medsenger, your personal chat assistant to guide you through the diagnosis of your discomfort!");
console.log("You are required to answer a few questions to get us started! To quit anytime, please press q");
console.log("\n");
console.log("1. Headache")
console.log("2. Chest pain")
console.log("3. Physical Injuries")
console.log("4. Stomach ache")
console.log("5. Skin")
console.log("Please select the type of injury. If you need multiple entries, please use format - Headache, Chest pain")
setTimeout(function() {disease_type("sjin, headache")},1000);
setTimeout(function() {symptom_des("i have a bursting pain and occurs regularly")},1000);

var possible = [];
function disease_type(data){
    var dis = data.toString().split(','); //array of number referring to injury type
    for(var i = 0; i < dis.length; i++){
        dis[i]=dis[i].toLowerCase().trim();
        if(skin.includes(dis[i])){
            dis[i] = "skin";
        }
    }
    console.log(dis)
    if(dis[0] === 'q'){
        console.log("Thank you for using Medsenger! Hope you were satisfied with the service.")
        process.exit(0);
    }
    dis_type = dis;
    
    // add smart reader for spelling autocorrect
}

function symptom_des(data) {
    var symptom = data.toString();
    var lst_symp = symptom.split(' ');
    var i = 0;
    var f = true;
    while(f && i < dis_type.length){
        if(injury[dis_type[i]]!=null){
            for(key in injury[dis_type[i]]){
                var counter = 0;
                for(var j = 0; j < lst_symp.length; j++){
                    if(injury[dis_type[i]][key].includes(lst_symp[j].trim())){
                        counter+=1;
                    }
                }
                if(counter/injury[dis_type[i]][key].length >= 0.5){
                    console.log(counter/injury[dis_type[i]][key].length);
                    possible.push(key);
                }
            }
        }
        i++;
    }
    console.log("Possible diseases: "+possible);
}